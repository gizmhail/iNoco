

# Open source components

## Base64
Base64, Copyright (C) 2012 Charcoal Design
https://github.com/nicklockwood/Base64

