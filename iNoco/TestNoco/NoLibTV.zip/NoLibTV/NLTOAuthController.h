//
//  NLTOAuthController.h
//  TestNoco
//
//  Created by Sébastien POIVRE on 18/06/2014.
//  Copyright (c) 2014 Sébastien Poivre. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NLTOAuthController : UIViewController <UIWebViewDelegate>

@end
